import game_framework
import start_state
import Main

game_framework.run(start_state)
