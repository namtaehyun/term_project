import game_framework
import urllib.request
from tkinter import *
import json

name = "Main"

def enter():
    global city
    pass

def exit():
    pass

def ShowCityInfo(text):
    url='http://api.openweathermap.org/data/2.5/weather?q='+text+'&mode=json&APPID=f2a4cd151d30cad7c8721aa75cf0d078'
    data = urllib.request.urlopen(url).read()
    j = json.loads(data)
    print(text+" is "+j['weather'][0]['main'])
    print("최고기온 : "+str(j['main']['temp_max']-273.15)+".c")
    print("최저기온 : "+str(j['main']['temp_min']-273.15)+".c")
    print("경도 : "+str(j['coord']['lat']))
    print("위도 : " + str(j['coord']['lon']))
    print("풍속 : " + str(j['wind']['speed'])+"m/s")
    print("습도 : "+str(j['main']['humidity']))

    window = Tk()
    window.title(text)
    window.geometry('200x200')  # width x height + 가로격자+세로격자
    l1 = Label(window,text="최고기온 : "+str(j['main']['temp_max']-273.15)+".c")
    l2 = Label(window,text="최저기온 : "+str(j['main']['temp_min']-273.15)+".c")
    l3 = Label(window,text="경   도 : "+str(j['coord']['lat']))
    l4 = Label(window,text="위   도 : "+ str(j['coord']['lon']))
    l5 = Label(window,text="풍   속 : "+ str(j['wind']['speed'])+"m/s")
    l6 = Label(window,text="습   도 : "+str(j['main']['humidity']))


    l1.pack()
    l2.pack()
    l3.pack()
    l4.pack()
    l5.pack()
    l6.pack()

    window.mainloop()

    pass

def run():
    global window
    window = Tk()
    window.title('기상정보')
    window.geometry('690x900')  # width x height + 가로격자+세로격자

    map = 'map.png'
    img = PhotoImage(file=map)

    map_label = Label(window, image=img)
    map_label.pack()

    button1 = Button(window, text="서울",command=lambda t="Seoul": ShowCityInfo(t))
    button1.place(x=326, y=442)

    button2 = Button(window, text='인천',command=lambda t="Incheon": ShowCityInfo(t))
    button2.place(x=280, y=471)

    button3 = Button(window, text='대전',command=lambda t="Daejeon": ShowCityInfo(t))
    button3.place(x=358, y=571)

    button4 = Button(window, text='대구',command=lambda t="Daegu": ShowCityInfo(t))
    button4.place(x=460, y=619)

    button5 = Button(window, text='광주',command=lambda t="Kwangju": ShowCityInfo(t))
    button5.place(x=314, y=694)

    button6 = Button(window, text='울산',command=lambda t="Ulsan": ShowCityInfo(t))
    button6.place(x=520, y=652)

    button7 = Button(window, text='부산',command=lambda t="Busan": ShowCityInfo(t))
    button7.place(x=503, y=692)

    button8 = Button(window, text='제주',command=lambda t="Jeju": ShowCityInfo(t))
    button8.place(x=246, y=872)

    button9 = Button(window, text='평양',command=lambda t="Pyongyang": ShowCityInfo(t))
    button9.place(x=224, y=281)

    button10 = Button(window, text='강릉',command=lambda t="Kang-neung": ShowCityInfo(t))
    button10.place(x=446, y=399)
    window.mainloop()


def pause():
    pass


def resume():
    pass







